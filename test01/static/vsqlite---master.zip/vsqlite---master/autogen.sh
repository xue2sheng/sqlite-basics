#!/bin/sh

echo "Generating autobuild environment..."
autoreconf --install --force > /dev/null

